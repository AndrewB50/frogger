﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
namespace Frogger
{


    class FroggerSprite
    {
        private Texture2D texture;
        private Rectangle position;
        private Color color;
        private float speed; // pixels per second
        private Direction direction;
        private bool visible;
        private Vector2 fPosition; // same as the position rectangle, but to a fraction of a pixel

        public FroggerSprite(Texture2D theImage, Rectangle thePosition, 
            Color theColor, float theSpeed, Direction theDirection, bool isVisible)
        {
            texture = theImage;
            position = thePosition;
            color = theColor;
            speed = theSpeed;
            direction = theDirection;
            visible = isVisible;
            fPosition.X = thePosition.X;
            fPosition.Y = thePosition.Y;
        }

        /********************* Property methods ********************/
        public Texture2D Texture
        {
            get { return texture; }
            set { texture = value; }
        }

        public Rectangle Position
        {
            get { return position; }
            set 
            { 
                position = value;
                fPosition.X = position.X;
                fPosition.Y = position.Y; 
            }
        }

        public Color Color
        {
            get { return color; }
            set { color = value; }
        }

        public float Speed
        {
            get { return speed; }
            set { speed = value; }
        }

        public bool Visible
        {
            get { return visible; }
            set { visible = value; }
        }

        public Direction Direction
        {
            get { return direction; }
            set { direction = value; }
        }


        /// <summary>
        /// Move in the current direction at the current speed
        /// </summary>
        public void Jump(Direction dir, int distance)
        {
            switch (dir)
            {
                case Direction.North: fPosition.Y -= distance; break;
                case Direction.South: fPosition.Y += distance; break;
                case Direction.East: fPosition.X += distance; break;
                case Direction.West: fPosition.X -= distance; break;
            }
            position.X = (int)fPosition.X;
            position.Y = (int)fPosition.Y;
            speed = 0;
        }

        public void Update()
        {
            switch (direction)
            {
                case Direction.North: fPosition.Y -= speed; break;
                case Direction.South: fPosition.Y += speed; break;
                case Direction.East: fPosition.X += speed; break;
                case Direction.West: fPosition.X -= speed; break;
            }
            //Console.WriteLine(position.X);
            position.X = (int)fPosition.X;
            position.Y = (int)fPosition.Y;
        }

        // Pass in the spriteBatch object so the sprite can draw itself.
        public void Draw(SpriteBatch spriteBatch)
        {
            if (visible)
                spriteBatch.Draw(texture, position, color);
        }
    }
}
